#ifndef __HEADFILE_H_
#define __HEADFILE_H_




#include "isr.h"
#include <string.h>
#include <stdio.h>
#include "intrins.h"
#include "math.h"
//------STC32G SDK??
#include "STC32Gxx.h"
#include "board.h"
#include "common.h"

//------??????????????????????
#include "zf_uart.h"
#include "zf_gpio.h"
#include "zf_iic.h"
#include "zf_adc.h"
#include "zf_spi.h"
#include "zf_tim.h"
#include "zf_pwm.h"
#include "zf_nvic.h"
#include "zf_exti.h"
#include "zf_delay.h"
#include "zf_eeprom.h"


//------????????????????
#include "SEEKFREE_FONT.h"
#include "SEEKFREE_IPS114_SPI.h"
#include "SEEKFREE_PRINTF.h"
#include "SEEKFREE_CONFIG.h"
#include "SEEKFREE_ICM20602.h"
#include "SEEKFREE_DL1A.h"
#include "SEEKFREE_DL1B.h"

//------��????18th???
#include "motor.h"
#include "adc.h"
#include "system_Init.h"
#include "schedule.h"
#include "encoder.h"
//#include "3IN1.h"
//#include "keyboard.h"
//#include "ch450.h"
//#include "AT24C.h"

//--------------------------???????��?4ms-------------------------------------

#define interrupt_4ms() pit_timer_ms(TIM_3,4)

//-------??????
#define     ABS(x)                (((x)>0)?(x):(-(x)))         //???x??????
#define     Min_data(a,b)                (((a)<(b))?(a):(b))        //a,b????��?
#define     Max_data(a,b)                (((a)>(b))?(a):(b))        //a,b??????
#define     Range(a,b,c)                (Max_data(a,Min_data(b,c)))            //??b??????[a,c]
#define     Limit(num, x)         ((num) < (x) ? 0 : (num))


#define     PI    3.14

#endif