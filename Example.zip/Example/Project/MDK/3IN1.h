//#ifndef __3IN1_H__
//#define __3IN1_H__

//#define i2c_write_register(ADD, REG, DATA) Keyboard_I2C_Write(ADD, REG, Keyboard_I2C_RegAddr8Bit, DATA)     /*!< д���� */
//#define Keyboard_IIC_Read(ADD, REG, DATA) Keyboard_I2C_Read(ADD, REG, Keyboard_I2C_RegAddr8Bit, DATA)       /*!< д���� */
//#define Keyboard_EEPROM_Read(ADD, REG, DATA) Keyboard_I2C_Read(ADD, REG, Keyboard_I2C_RegAddr16Bit, DATA) /*!< ��ȡ�ֿ⺯�� */
//#define Keyboard_CH455_Read(ADD, DATA) Keyboard_I2C_Read(ADD, 0x00, Keyboard_I2C_NoSubaddress, DATA)        /*!< CH455��ȡ���� */
//#define Keyboard_CH455_Write(ADD, DATA) Keyboard_I2C_Write(ADD, 0x00, Keyboard_I2C_NoSubaddress, DATA)      /*!< CH455д�뺯�� */

//#define i2c_Start() Keyboard_I2C_Start()
//#define i2c_Stop() Keyboard_I2C_Stop()
//#define i2c_Wait() Keyboard_I2C_Wait_Ack()
//#define i2c_write_byte(x) Keyboard_I2C_WriteByte(x)

//#define device_add0 0x78

//void K_OLED_Init(void);
//void fill_picture(uint8 fill_Data);
//void OLED_Clear(void);
//void OLED_Setxy(unsigned char x, unsigned char y);
//void OLED_RAM_ShowChar0816_add(uint16 x, uint16 y, int chr);
//void OLED_ShowStr(uint8 x, uint8 y, const int8 ch[]);
//void OLED_RAM_Show(uint16 x, uint16 y, int chr);
//void OLED_RAM_Refresh_add(void);
//void OLED_RAM_Fill_add_ClearLine(uint8 line);
//#endif