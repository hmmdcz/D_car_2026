#ifndef __ADRC_H__
#define __ADRC_H__

#include "headfile.h"

extern float fhan(float x1, float x2, float r, float h);
extern float sign(float x);
extern float ADRC(float v, float y);
extern float fal(float e, float alpha, float delta);

#endif