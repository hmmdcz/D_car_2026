#ifndef _Tfmini_h_
#define _Tfmini_h_

#include "headfile.h"

#define TF_UART                   UART_2
#define TF_UART_BAUD            115200
#define TF_UART_RX_PIN          UART2_RX_P10
#define TF_UART_TX_PIN          UART2_TX_P11
#define TF_UART_TIM               TIM_2
#define TF_UART_DATA_SBUF       S2BUF


#define TF_UART_BUFFER_SIZE     9



extern void Tfmini_Read(void);
extern void Tfmini_Init(void);
extern uint16   TF_Dist;
extern uint16   TF_AMP;
extern uint8    TF_RecieveFlag;
#endif
