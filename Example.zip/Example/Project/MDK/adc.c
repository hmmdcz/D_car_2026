#include "adc.h"

//*********��в���*****************//
uint16 AD_L = 0;
uint16 AD_R = 0;


int32 AD_Left = 0;
int32 AD_Right = 0;



uint16 AD_L_min = 0;
uint16 AD_L_max = 250;

uint16 AD_R_min = 0;
uint16 AD_R_max = 250;

//�Ƿ��һ��
int normalization_flag = 1;



void ADC_AllInit(void)
{
    L_ADC_Init(); //��·��г�ʼ��
    R_ADC_Init(); //��·��г�ʼ��
}

uint16 Get_ADC(int num)
{
    uint16 a, b, c, temp;

    switch (num) {
        case 1 :
            a = L_Get_ADC_Value();
            b = L_Get_ADC_Value();
            c = L_Get_ADC_Value();
            break;

        case 2 :
            a = R_Get_ADC_Value();
            b = R_Get_ADC_Value();
            c = R_Get_ADC_Value();
            break;



        default :
            break;
    }

    if (a > b) {
        temp = a;
        a = b;
        b = temp;
    }

    if (c > b) {
        temp = b;
    }
    else if (c > a) {
        temp = c;
    }
    else {
        temp = a;
    }

    return temp;
}




void ADC_Update(void)
{



    uint32 sum_L = 0, sum_R = 0;
    int i;

    for (i = 0; i < 5; i++) {                 //ƽ��ֵ�˲�

        sum_L += Get_ADC(1);
        sum_R += Get_ADC(2);
    }

    sum_L /= 5;
    sum_R /= 5;

    AD_L = sum_L; //��
    AD_R = sum_R; //��


    if (normalization_flag) {

        AD_L /=10;  //��Ҳ��֪��ΪɶҪ��10
        AD_L = Range(AD_L_min, AD_L, AD_L_max);                        //��һ��
        AD_L = (AD_L- AD_L_min) * 100 / (AD_L_max- AD_L_min);

        AD_R /=10;
        AD_R = Range(AD_R_min, AD_R, AD_R_max);
        AD_R = (AD_R- AD_R_min) * 100 / (AD_R_max- AD_R_min);



    }




}







uint16 MedianFilter(uint16* adc_data, int length)
{
    uint16 max = adc_data[0];
    uint16 min = adc_data[0];
    int sum = 0;
    int i;

    for (i = 0; i < length; i++) {
        sum += adc_data[i];

        if (adc_data[i] > max) {
            max = adc_data[i];
        }

        if (adc_data[i] < min) {
            min = adc_data[i];
        }
    }

    sum = sum - max - min;

    return sum / (length - 2);
}

/************************
    ������е�Ȩ�ؼ����е�ģ
*************************/
uint16 calculate_vec(float Pal_weight, uint16 AD_1, float Ver_weight, uint16 AD_2)
{

    uint16 result = (uint16)(sqrt(Pal_weight * Pal_weight * AD_1 * AD_1 + Ver_weight * Ver_weight * AD_2 * AD_2));
    return result;

}


