#ifndef __ADC_H
#define __ADC_H


#include "headfile.h"


//�޷�����
#define limit_adc(x ,a , b) ((x) < (a) ? (a) : ( (x) > (b) ? (b) : (x)))

//��вɼ�


//�������2��
#define L_ADC_Init() adc_init(ADC_P17, ADC_SYSclk_DIV_2)
#define L_Get_ADC_Value() adc_once(ADC_P17, ADC_12BIT)

//�м丨��3��
#define R_ADC_Init() adc_init(ADC_P16, ADC_SYSclk_DIV_2)
#define R_Get_ADC_Value() adc_once(ADC_P16, ADC_12BIT)

////�ɼ���ص�ѹ
//#define Power_ADC_Init()  adc_init(ADC_P13, ADC_SYSclk_DIV_2)
//#define Get_Power_Value() adc_once(ADC_P13, ADC_12BIT)



//*********��в���*****************//����Ҫint16

extern uint16 AD_L;
extern uint16 AD_R;


extern int32 AD_Left;
extern int32 AD_Right;

extern uint16 AD_L_min;
extern uint16 AD_L_max;

extern uint16 AD_R_min;
extern uint16 AD_R_max;



extern int normalization_flag;




/* �������� ---------------------------------------------------------------- */
extern uint16 Get_ADC(int num);
extern void ADC_Update(void);
extern void ADC_Update1(void);
extern void ADC_AllInit(void);

extern uint16 Get_POWER(void);

uint16 MedianFilter(uint16* adc_data, int length);
uint16 normalization(uint16 dmin, uint16 dat, uint16 dmax);
uint16 calculate_vec(float Pal_weight, uint16 AD_1, float Ver_weight, uint16 AD_2);








#endif