#include "headfile.h"

/*
  * @describe �߾�������
  * @param Angle:����Ƕ�����100��
  * @return ���ֵ����10000��
  * example: sin(30) = 0.5  sin_10000(30*100) = 0.5 * 10000
  */
signed int sin_value_10000(unsigned long Angle)
{
    long Angle_value = 0;

    if (Angle < 1500) {
        Angle_value = 1757 * Angle / 1000 - 196 * Angle * Angle / 10000000;
    }
    else if (Angle < 3000) {
        Angle_value = 187 * Angle / 100 - 58 * Angle * Angle / 1000000 - 88;
    }
    else if (Angle < 4500) {
        Angle_value = 2078 * Angle / 1000 - 93 * Angle * Angle / 1000000 - 397;
    }
    else if (Angle < 6000) {
        Angle_value = 232 * Angle / 100 - 12 * Angle * Angle / 100000 - 940;
    }
    else {
        Angle = 9000 - Angle;
        Angle_value = 10000 - 944 * Angle / 100000 - 146 * Angle * Angle / 1000000;
    }

    return Angle_value;
}
/*
 * @describe �߾�������
 * @param Angle:����Ƕ�����100��
 * @return ���ֵ����10000��
 * example: sin(30) = 0.5  sin_10000(30*100) = 0.5 * 10000
 */
signed int sin_10000(signed long Angle)
{
    signed int SinValue = 0;

    while (Angle > 36000) {
        Angle = Angle - 36000;
    }

    while (Angle < 0) {
        Angle = Angle + 36000;
    }

    if (Angle <= 9000) {
        SinValue = sin_value_10000(Angle);
    }
    else if (Angle <= 18000) {
        SinValue = 18000 - Angle;
        SinValue = sin_value_10000(SinValue);
    }
    else if (Angle <= 27000) {
        SinValue = Angle - 18000;
        SinValue = 0 - sin_value_10000(SinValue);
    }
    else {
        SinValue = 36000 - Angle;
        SinValue = 0 - sin_value_10000(SinValue);
    }

    return SinValue;
}




/*
 * @describe arcsin()����
 * @param Angle:����Ƕ�����100��
 * @return ���ֵ����10000��
 * example: sin(30) = 0.5  sin_10000(30*100) = 0.5 * 10000
 * ����(-10000,10000),���(-9000,9000)
 */
signed long arcsin_10000(signed int value)
{
    int vax, r;
    int down, up, mid;

    if (value < sin_10000(-8999)) {
        return -8999;
    }
    else if (value > sin_10000(8999)) {
        return 8999;
    }

    vax = ABS(value);
    down = -8999;
    mid = 0;
    up = 8999;

    while (up >= down) {  //���ַ�
        if (vax > sin_10000(mid)) {
            down = mid + 1;
        }
        else {
            up = mid - 1;
        }

        mid = (up + down) >> 1;
    }

    r = (vax - sin_10000(up)) / (sin_10000(down) - sin_10000(up)) + up; //���Բ�ֵ

    if (value < 0)
        r = -r;

    return r;
}
