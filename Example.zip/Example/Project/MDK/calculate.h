#ifndef __CALCULATE_H
#define __CALCULATE_H

extern signed long arcsin_10000(signed int value);

#endif
