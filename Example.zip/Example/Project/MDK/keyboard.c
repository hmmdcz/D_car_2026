//#include "keyboard.h"

//uint16 ZLG7290GetKeyAndDisplay(void)
//{
//    uint8 xdata i, tmp = 0;
//    uint16 xdata rt = 0;

//    //    OLED_Clear();
//    OLED_RAM_Refresh_add();

//    for (i = 0; i < 8;) {
//        while (CH450_INT);

//        tmp = CH450_Read();

//        while (!CH450_INT);

//        if (tmp == 0x0a) {
//            i=0;
//            rt = 0;
//            //            OLED_Clear();
//            OLED_RAM_Fill_add_ClearLine(4);
//            OLED_RAM_Refresh_add();

//            while (!CH450_INT);

//            continue;
//        }
//        else if (tmp == 0x0b) return rt;
//        else if (tmp == 0xff) continue;
//        else {
//            if (rt * 10 + tmp > 65000) {
//                continue;
//            }

//            rt = rt * 10 + tmp;
//            i++;
//            OLED_RAM_Show(0, 6, rt);
//            OLED_RAM_Refresh_add();
//        }

//        while (!CH450_INT);
//    }

//    return rt;
//}


//void Choise(void)//ѡ�񰴼���Ӧ����
//{

//    int xdata i = 0;
//    int xdata stall = 0;
//		int xdata tmp = 0;
//    int16 SM_temp = 0;

//    int xdata choise = 0;
//    int xdata choice_1 = 6;
//    int xdata choice_2 = 6;
//    int xdata choice_3 = 6;
//    int xdata choice_4 = 6;
//    Keyboard_I2C_Init();
//    CH455_Init() ;
//    K_OLED_Init() ;
//    fill_picture(0xff);
//    fill_picture(0x00);
//    P22 = 0;    //���̳�ʼ���󣬲��Եƻ���


//    while (1) {

//        OLED_Clear();

//        OLED_ShowStr(0, 0, "1:MODE 2:ENABLE");
//        OLED_ShowStr(0, 2, "3:MEMORY4:STALL");
//        OLED_ShowStr(0, 4, "5:SET 6:ELEMENT");
//        OLED_ShowStr(56, 6, "Main menu");
//        OLED_RAM_Refresh_add();
//        choise = ZLG7290GetKeyAndDisplay();

//        if (choise == 0x00) {                                                       //break
//            OLED_Clear();
//            OLED_RAM_Refresh_add();
//            break;
//        }

//        if (choise == 0x01) {                                                       //modeԤ�裬test_mode��test_mode��run_time
//            OLED_Clear();
//            OLED_RAM_Refresh_add();
//            Mode_Test();
//        }

//        if (choise == 0x02) {                                                       //��ʼ��
//            for (;;)

//            {
//                OLED_Clear();
//                OLED_ShowStr(8, 0, "1:RING 2:BRIDGE");
//                OLED_ShowStr(8, 2, "3:DOWN 4:MEMORY");
//                OLED_ShowStr(8, 4, "5:DETOUR");
//                OLED_RAM_Refresh_add();
//                SM_temp = ZLG7290GetKeyAndDisplay();
//                choice_1 = SM_temp;

//                

//                if (choice_1 == 0) {
//                    OLED_Clear();

//                    break;
//                }


//            }
//        }

//        if (choise == 0x03) {
//            //Ԫ�ؼ���
//            OLED_Clear();
//            OLED_RAM_Refresh_add();
//            Memory_Set();

//        }

//        if (choise == 0x04) {                                                       //��λ
//            OLED_Clear();
//            OLED_ShowStr(8, 0, "STALL");
//            OLED_ShowStr(8, 2, "1:L 2:M 3:H");
//            OLED_ShowStr(8, 4, "4:HOME");
//            OLED_RAM_Refresh_add();
//            SM_temp = ZLG7290GetKeyAndDisplay();
//            stall = SM_temp;
//            OLED_Clear();

//            switch (stall) {

//               case 1://low_speed



//                    OLED_ShowStr(8, 4, "OK");
//                    OLED_RAM_Refresh_add();

//                    break;

//                case 2: //mid_speed


//                    OLED_ShowStr(8, 4, "OK");
//                    OLED_RAM_Refresh_add();

//                    break;

//                case 3:    //High_Speed

//                    

//                    OLED_ShowStr(8, 4, "OK");
//                    OLED_RAM_Refresh_add();

//                    break;

//                case 4:

//					

//                    OLED_ShowStr(8, 4, "OK");
//                    OLED_RAM_Refresh_add();
//                    break;
//            }
//        }

//        if (choise == 0x05) {
//            for (;;) {
//                OLED_Clear();
//                OLED_ShowStr(8, 0, "SET");
//                OLED_ShowStr(8, 2, "1:PID_Mode");
//                OLED_ShowStr(8, 4, "2:AD 3:SEE");


//                OLED_RAM_Refresh_add();
//                SM_temp = ZLG7290GetKeyAndDisplay();
//                choice_1 = SM_temp;

//                if (choice_1 == 1) {



//                    OLED_Clear();
//                    OLED_ShowStr(8, 0, "1:Mode");

//                    OLED_RAM_Refresh_add();

//                    OLED_RAM_Refresh_add();
//                    SM_temp = ZLG7290GetKeyAndDisplay();
//                    choice_2 = SM_temp;

//                    if (choice_2 == 1) {
//                        OLED_Clear();
//                        OLED_ShowStr(8, 0, "Mode");
//                        OLED_RAM_Show(8, 2, PID_Mode);
//                        SM_temp = ZLG7290GetKeyAndDisplay();
//                        PID_Mode = SM_temp;

//                        AT24C_SendLenByte(0x0204, PID_Mode);
//                    }



//                    if (choice_2 == 0) {
//                        OLED_Clear();
//                        OLED_ShowStr(8, 0, "BREAK");
//                        OLED_RAM_Refresh_add();
//                        break;
//                    }



//                    if (choice_1 == 0) {
//                        OLED_Clear();
//                        OLED_ShowStr(8, 0, "BREAK");
//                        OLED_RAM_Refresh_add();

//                        break;
//                    }





//                }

//                if (choice_1 == 2) {
//                    OLED_Clear();
//                    AD_Set();
//                }

//                if (choice_1 == 3) {
//                    OLED_Clear();
//                    OLED_ShowStr(8, 0, "SEE");
//                    OLED_RAM_Refresh_add();
//                    Scr_Set();
//                }

//                if (choice_1 == 0) {
//                    OLED_Clear();
//                    OLED_ShowStr(8, 0, "BREAK");
//                    OLED_RAM_Refresh_add();

//                    break;
//                }





//            }

//        }

//        if (choise == 0x06) {
//            OLED_Clear();
//            Element_Set();
//        }

//        if (choise == 0x07) {
//            OLED_Clear();
//            Turn_PPP();
//        }



//        if (choise == 0x08) {
//            OLED_Clear();
//            Turn_DDD();
//        }

////        if (choise == 0x09) {
////            OLED_Clear();
////            Turn_Gyr();
////        }

////        if (choise == 0x0A) {
////            OLED_Clear();
////            Speed_Mode_set();
////        }

////        if (choise == 0x0B) {
////            OLED_Clear();
////            Speed_Low_set();
////        }

////        if (choise == 0x0C) {
////            OLED_Clear();
////            K_N_Set();
////        }
////				
////				if (choise == 0x0d) {

////            OLED_Clear();
//////			AT24C_SendLenByte(0x0412, sPID_SpeedL.Kp);
//////		AT24C_SendLenByte(0x0414, sPID_SpeedL.Ki);
//////		AT24C_SendLenByte(0x0416, sPID_SpeedR.Kp);
//////		AT24C_SendLenByte(0x0418, sPID_SpeedR.Ki);
////						OLED_ShowStr(8, 0, "L_PID");
////            OLED_RAM_Show(8, 2, sPID_SpeedL.Kp );
////						OLED_RAM_Show(8, 4, sPID_SpeedL.Ki );
////					  OLED_RAM_Refresh_add();
////						tmp = CH450_Read();
////							
//////							if (CH450_Read() == 0x0b)
//////						{
//////							OLED_Clear();
//////							break;
//////						}
////            
////					  SM_temp = ZLG7290GetKeyAndDisplay();
////            sPID_SpeedL.Kp = SM_temp;
////            OLED_RAM_Fill_add_ClearLine(4);					
////						SM_temp = ZLG7290GetKeyAndDisplay();
////            sPID_SpeedL.Ki = SM_temp;

////            AT24C_SendLenByte(0x0412, sPID_SpeedL.Kp);
////						AT24C_SendLenByte(0x0414, sPID_SpeedL.Ki);
////					
////        }
////				
////				if (choise == 0x0e)
////				{
////						OLED_Clear();
////						OLED_ShowStr(8, 0, "R_PID");
////            OLED_RAM_Show(8, 2, sPID_SpeedR.Kp );
////						OLED_RAM_Show(8, 4, sPID_SpeedR.Ki );
////					  OLED_RAM_Refresh_add();
////						tmp = CH450_Read();
////							
//////							if (CH450_Read() == 0x0b)
//////						{
//////							OLED_Clear();
//////							break;
//////						}
////            
////			SM_temp = ZLG7290GetKeyAndDisplay();
////            sPID_SpeedR.Kp = SM_temp;
////            OLED_RAM_Fill_add_ClearLine(4);					
////			SM_temp = ZLG7290GetKeyAndDisplay();
////            sPID_SpeedR.Ki = SM_temp;
////            AT24C_SendLenByte(0x0416, sPID_SpeedR.Kp);
////			AT24C_SendLenByte(0x0418, sPID_SpeedR.Ki);
////			
////				
////				}

//    }

////    if (test_mode == 0) {
////        OLED_ShowStr(8, 0, "Mode:   Run");
////    }

////    if (test_mode == 1) {
////        OLED_ShowStr(8, 0, "Mode:   Test");
////    }

////    if (test_mode == 3) {
////        OLED_ShowStr(8, 0, "Mode:   PID");
////    }

////    if (stall == 0) {
////        OLED_ShowStr(8, 2, "STALL:   NO");
////    }

////    if (stall == 1) {
////        OLED_ShowStr(8, 2, "STALL:  LOW");
////    }

////    if (stall == 2) {
////        OLED_ShowStr(8, 2, "STALL:  MID");
////    }

////    if (stall == 3) {
////        OLED_ShowStr(8, 2, "STALL:  HIGH");
////    }

////    if (stall == 4) {
////        OLED_ShowStr(8, 2, "STALL:  HOME");
////    }

//    OLED_ShowStr(16, 6, "Go.....");

//    OLED_RAM_Refresh_add();
//}

/////************************************************���ܺ���***********************************************/

////uint8 dir = 0;//0Ϊ- 1Ϊ+
//void K_N_Set(void)
//{
//    uint8 xdata tmp = 0;
//    int16 SM_temp = 0;
//    int xdata choice_1 = 6;

//    for (;;) {
//        P22 = 1;
//        OLED_Clear();
//        OLED_ShowStr(8, 0, "TRACK");
//        OLED_ShowStr(8, 4, "1:VW 2:PW");
//        SM_temp = ZLG7290GetKeyAndDisplay();
//        choice_1 = SM_temp;

//        if (choice_1 == 0) {
//            OLED_Clear();
//            OLED_ShowStr(8, 0, "BREAK");
//            OLED_RAM_Refresh_add();

//            break;
//        }

//        if (choice_1 == 1) {
//            OLED_Clear();
//            OLED_ShowStr(8, 0, "Ver_weight");
//            OLED_RAM_Show(8, 2, Default.Ver_weight);
//            OLED_RAM_Refresh_add();

//            SM_temp = ZLG7290GetKeyAndDisplay();
//            Default.Ver_weight = SM_temp;

//            AT24C_SendLenByte(0x0718, Default.Ver_weight);

//        }

//        if (choice_1 == 2) {
//            OLED_Clear();
//            OLED_ShowStr(8, 0, "Pal_weight");
//            OLED_RAM_Show(8, 2, Default.Pal_weight);
//            OLED_RAM_Refresh_add();

//            SM_temp = ZLG7290GetKeyAndDisplay();
//            Default.Pal_weight = SM_temp;

//            AT24C_SendLenByte(0x071a, Default.Pal_weight);

//        }

//    }

//}
//void Element_Set(void)
//{
//    uint8 xdata tmp = 0;
//    int16 SM_temp = 0;
//    int xdata choice_1 = 6;
//    int xdata choice_2 = 6;

//    for (;;)

//    {

//        OLED_Clear();
//        OLED_ShowStr(8, 0, "ELEMENT");
//        OLED_ShowStr(8, 2, "1:RING 2:BRIDGE");
//        OLED_ShowStr(8, 4, "3:DETOUR ");
//        OLED_RAM_Refresh_add();
//        SM_temp = ZLG7290GetKeyAndDisplay();
//        choice_1 = SM_temp;

//        if (choice_1 == 0) {
//            OLED_Clear();
//            OLED_ShowStr(8, 0, "BREAK");
//            OLED_RAM_Refresh_add();

//            break;
//        }

//        if (choice_1 == 1) {


//            OLED_Clear();

//        }

//        if (choice_1 == 2) {
//            OLED_Clear();

//            for (;;)

//            {

//            }

//        }


//        if (choice_1 == 3) {

//            OLED_Clear();

//        }



//    }


//}


//void Mode_Test(void)
//{
//    uint8 xdata tmp = 0;
//    int16 SM_temp = 0;
//    int xdata choice_1 = 6;
//    int xdata choice_2 = 6;

//    OLED_Clear();
//    OLED_ShowStr(8, 0, "MODE_TEST");
//    OLED_ShowStr(8, 2, "1:MODE_Set");
//    OLED_ShowStr(8, 4, "2:TIME_Set");
//    OLED_RAM_Refresh_add();
//    SM_temp = ZLG7290GetKeyAndDisplay();
//    choice_1 = SM_temp;
//    OLED_Clear();

//    switch (choice_1) {
//        case 1:
//            OLED_ShowStr(8, 0, "MODE_SET ");
//            OLED_ShowStr(8, 2, "0:NO 1:TIME");
//            OLED_ShowStr(8, 4, "3:PID");
//            OLED_ShowStr(48, 6, "mode:");
//            OLED_RAM_Show(88, 6, test_mode);
//            OLED_RAM_Refresh_add();


//            SM_temp = ZLG7290GetKeyAndDisplay();
//            test_mode = SM_temp;

//            AT24C_SendLenByte(0x0100, test_mode);
//            OLED_Clear();
//            break;

//        case 2:
//            for (;;) {
//                OLED_ShowStr(8, 0, "TIME_SET");
//                OLED_ShowStr(8, 2, "1:START 2:TEST");
//                OLED_ShowStr(8, 4, "3:RUN  0:BREAK");
//                OLED_RAM_Refresh_add();
//                SM_temp = ZLG7290GetKeyAndDisplay();
//                choice_2 = SM_temp;
//                OLED_Clear();

//                if (choice_2 == 1) {

//                    OLED_ShowStr(8, 0, "1:START_TIME");
//                    OLED_RAM_Show(8, 2, start_time);
//                    OLED_RAM_Refresh_add();

//                    SM_temp = ZLG7290GetKeyAndDisplay();
//                    start_time = SM_temp;

//                    AT24C_SendLenByte(0x0102, start_time);
//                    OLED_Clear();
//                }

//                if (choice_2 == 2) {
//                    OLED_ShowStr(8, 0, "2:TEST_TIME");
//                    OLED_RAM_Show(8, 2, test_time);
//                    OLED_RAM_Refresh_add();

//                    SM_temp = ZLG7290GetKeyAndDisplay();
//                    test_time = SM_temp;

//                    AT24C_SendLenByte(0x0104, test_time);
//                    OLED_Clear();
//                }

//                if (choice_2 == 3) {
//                    OLED_ShowStr(8, 0, "3:RUN_TIME");
//                    OLED_RAM_Show(8, 2, run_time);
//                    OLED_RAM_Refresh_add();

//                    SM_temp = ZLG7290GetKeyAndDisplay();
//                    run_time = SM_temp;

//                    AT24C_SendLenByte(0x0106, run_time);
//                    OLED_Clear();
//                }

//                if (choice_2 == 0) {

//                    OLED_Clear();
//                    break;
//                }
//            }

//            break;



//        default:
//            OLED_Clear();
//    }

//    OLED_Clear();
//}
//void Speed_Low_set(void)
//{
//    int16 SM_temp = 0;
//    int xdata choice_1 = 6;
//    int xdata choice_2 = 6;


//    for (;;) {

//        OLED_ShowStr(8, 0, "V_LOW");
//        OLED_ShowStr(8, 2, "Default_V");
//        OLED_RAM_Refresh_add();

//        SM_temp = ZLG7290GetKeyAndDisplay();
//        choice_1 = SM_temp;
//        OLED_Clear();

//        if (choice_1 == 1) {
//            OLED_ShowStr(8, 0, "Default_V");
//            OLED_RAM_Show(8, 2, Speed_Low);
//            OLED_RAM_Refresh_add();
//            SM_temp = ZLG7290GetKeyAndDisplay();
//            Speed_Low = SM_temp;
//            AT24C_SendLenByte(0x0810, Speed_Low);
//            OLED_Clear();
//        }

//        if (choice_1 == 0) {
//            OLED_Clear();
//            break;
//        }

//    }

//    OLED_ShowStr(2, 6, "Finish");
//    OLED_RAM_Refresh_add();
//    delay_ms(250);
//    OLED_Clear();

//}
//void Speed_Mode_set(void)
//{
//    int16 SM_temp = 0;
//    int xdata choice_1 = 6;
//    int xdata choice_2 = 6;


//    for (;;) {
//        OLED_ShowStr(0, 0, "1:default 2:down");
//        OLED_ShowStr(0, 2, "3:ring 4:detour");
//        OLED_ShowStr(0, 4, "5:brige");
//        OLED_ShowStr(64, 6, "V_SET");
//        OLED_RAM_Refresh_add();

//        SM_temp = ZLG7290GetKeyAndDisplay();
//        choice_1 = SM_temp;
//        OLED_Clear();

//        if (choice_1 == 1) {
//            OLED_ShowStr(8, 0, "Default_V");
//            OLED_RAM_Show(8, 2, Speed_Ref[0]);
//            OLED_RAM_Refresh_add();
//            SM_temp = ZLG7290GetKeyAndDisplay();
//            Speed_Ref[0] = SM_temp;
//            AT24C_SendLenByte(0x0700, Speed_Ref[0]);
//            OLED_Clear();
//        }

//        if (choice_1 == 2) {
//            OLED_ShowStr(8, 0, "Decelerate_V");
//            OLED_RAM_Show(8, 2, Speed_Ref[1]);
//            OLED_RAM_Refresh_add();
//            SM_temp = ZLG7290GetKeyAndDisplay();
//            Speed_Ref[1] = SM_temp;
//            AT24C_SendLenByte(0x0702, Speed_Ref[1]);
//            OLED_Clear();
//        }

//        if (choice_1 == 3) {
//            OLED_ShowStr(8, 0, "Ring_V");
//            OLED_RAM_Show(8, 2, Speed_Ref[2]);
//            OLED_RAM_Refresh_add();
//            SM_temp = ZLG7290GetKeyAndDisplay();
//            Speed_Ref[2]  = SM_temp;
//            AT24C_SendLenByte(0x0704, Speed_Ref[2]);
//            OLED_Clear();
//        }

//        if (choice_1 == 4) {
//            OLED_ShowStr(8, 0, "Detour_V");
//            OLED_RAM_Show(8, 2, Speed_Ref[3]);
//            OLED_RAM_Refresh_add();
//            SM_temp = ZLG7290GetKeyAndDisplay();
//            Speed_Ref[3]  = SM_temp;
//            AT24C_SendLenByte(0x0706, Speed_Ref[3]);
//            OLED_Clear();
//        }

//        if (choice_1 == 5) {
//            OLED_ShowStr(8, 0, "Brige_V");
//            OLED_RAM_Show(8, 2, Speed_Ref[4]);
//            OLED_RAM_Refresh_add();
//            SM_temp = ZLG7290GetKeyAndDisplay();
//            Speed_Ref[4]  = SM_temp;
//            AT24C_SendLenByte(0x0708, Speed_Ref[4]);
//            OLED_Clear();
//        }

//        if (choice_1 == 0) {
//            OLED_ShowStr(8, 0, "Skip");
//            OLED_RAM_Refresh_add();
//            delay_ms(250);
//            OLED_Clear();
//            break;
//        }

//    }

//    OLED_Clear();
//}

//void Turn_DDD(void)
//{
//    int16 SM_temp = 0;
//    int xdata choice_1 = 6;


//    for (;;) {
//        OLED_ShowStr(0, 0, "1:default 2:down");
//        OLED_ShowStr(0, 2, "3:ring 4:detour");
//        OLED_ShowStr(0, 4, "5:brige");
//        OLED_ShowStr(64, 6, "D_SET");
//        OLED_RAM_Refresh_add();

//        SM_temp = ZLG7290GetKeyAndDisplay();
//        choice_1 = SM_temp;
//        OLED_Clear();

//        if (choice_1 == 1) {
//            OLED_ShowStr(8, 0, "default_turn_d");
//            OLED_RAM_Show(8, 2, turn_d[0]);
//            OLED_RAM_Refresh_add();
//            SM_temp = ZLG7290GetKeyAndDisplay();
//            turn_d[0] = SM_temp;
//            AT24C_SendLenByte(0x0500, turn_d[0]);
//            OLED_Clear();
//        }

//        if (choice_1 == 2) {
//            OLED_ShowStr(8, 0, "decelerate_turn_d");
//            OLED_RAM_Show(8, 2, turn_d[1]);
//            OLED_RAM_Refresh_add();
//            SM_temp = ZLG7290GetKeyAndDisplay();
//            turn_d[1] = SM_temp;
//            AT24C_SendLenByte(0x0502, turn_d[1]);
//            OLED_Clear();
//        }

//        if (choice_1 == 3) {
//            OLED_ShowStr(8, 0, "ring_turn_d");
//            OLED_RAM_Show(8, 2, turn_d[2]);
//            OLED_RAM_Refresh_add();
//            SM_temp = ZLG7290GetKeyAndDisplay();
//            turn_d[2] = SM_temp;
//            AT24C_SendLenByte(0x0504, turn_d[2]);
//            OLED_Clear();
//        }

//        if (choice_1 == 4) {
//            OLED_ShowStr(8, 0, "detour_turn_d");
//            OLED_RAM_Show(8, 2, turn_d[3]);
//            OLED_RAM_Refresh_add();
//            SM_temp = ZLG7290GetKeyAndDisplay();
//            turn_d[3] = SM_temp;
//            AT24C_SendLenByte(0x0506, turn_d[3]);
//            OLED_Clear();
//        }

//        if (choice_1 == 5) {
//            OLED_ShowStr(8, 0, "brige_turn_d");
//            OLED_RAM_Show(8, 2, turn_d[4]);
//            OLED_RAM_Refresh_add();
//            SM_temp = ZLG7290GetKeyAndDisplay();
//            turn_d[4] = SM_temp;
//            AT24C_SendLenByte(0x0508, turn_d[4]);
//            OLED_Clear();
//        }


//        if (choice_1 == 0) {
//            OLED_Clear();
//            break;
//        }
//    }

//    OLED_Clear();

//}
//void Turn_PPP(void)
//{
//    int16 SM_temp = 0;
//    int xdata choice_1 = 6;

//    for (;;) {
//        OLED_ShowStr(0, 0, "1:default 2:down");
//        OLED_ShowStr(0, 2, "3:ring 4:barrier");
//        OLED_ShowStr(0, 4, "5:brige");
//        OLED_ShowStr(64, 6, "P_SET");
//        OLED_RAM_Refresh_add();

//        SM_temp = ZLG7290GetKeyAndDisplay();
//        choice_1 = SM_temp;
//        OLED_Clear();

//        if (choice_1 == 1) {
//            OLED_ShowStr(8, 0, "default_turn_p");
//            OLED_RAM_Show(8, 2, turn_p_base[0]);
//            OLED_RAM_Refresh_add();

//            SM_temp = ZLG7290GetKeyAndDisplay();
//            turn_p_base[0] = SM_temp;
//            AT24C_SendLenByte(0x0400, turn_p_base[0]);
//            OLED_Clear();
//        }

//        if (choice_1 == 2) {
//            OLED_ShowStr(8, 0, "decelerate_turn_p");
//            OLED_RAM_Show(8, 2, turn_p_base[1]);
//            OLED_RAM_Refresh_add();

//            SM_temp = ZLG7290GetKeyAndDisplay();
//            turn_p_base[1] = SM_temp;
//            AT24C_SendLenByte(0x0402, turn_p_base[1]);
//            OLED_Clear();
//        }

//        if (choice_1 == 3) {
//            OLED_ShowStr(8, 0, "ring_turn_p");
//            OLED_RAM_Show(8, 2, turn_p_base[2]);
//            OLED_RAM_Refresh_add();

//            SM_temp = ZLG7290GetKeyAndDisplay();
//            turn_p_base[2]  = SM_temp;
//            AT24C_SendLenByte(0x0404, turn_p_base[2]);
//            OLED_Clear();
//        }

//        if (choice_1 == 4) {
//            OLED_ShowStr(8, 0, "detour_turn_p");
//            OLED_RAM_Show(8, 2, turn_p_base[3]);
//            OLED_RAM_Refresh_add();

//            SM_temp = ZLG7290GetKeyAndDisplay();
//            turn_p_base[3]  = SM_temp;
//            AT24C_SendLenByte(0x0406, turn_p_base[3]);
//            OLED_Clear();
//        }

//        if (choice_1 == 5) {
//            OLED_ShowStr(8, 0, "brige_turn_p");
//            OLED_RAM_Show(8, 2, turn_p_base[4]);
//            OLED_RAM_Refresh_add();

//            SM_temp = ZLG7290GetKeyAndDisplay();
//            turn_p_base[4]  = SM_temp;
//            AT24C_SendLenByte(0x0408, turn_p_base[4]);
//            OLED_Clear();
//        }


//        if (choice_1 == 0) {

//            OLED_Clear();
//            break;


//        }

//        OLED_Clear();

//    }
//}

//void Turn_Gyr(void)
//{
//    int16 SM_temp = 0;
//    int xdata choice_1 = 6;

//    for (;;) {
//        OLED_ShowStr(0, 0, "1:default 2:down");
//        OLED_ShowStr(0, 2, "3:ring 4:detour");
//        OLED_ShowStr(0, 4, "5:brige");
//        OLED_ShowStr(64, 6, "G_SET");
//        OLED_RAM_Refresh_add();

//        SM_temp = ZLG7290GetKeyAndDisplay();
//        choice_1 = SM_temp;
//        OLED_Clear();

//        if (choice_1 == 1) {
//            OLED_ShowStr(8, 0, "default_turn_g");
//            OLED_RAM_Show(8, 2, turn_gyro[0]);
//            OLED_RAM_Refresh_add();
//            SM_temp = ZLG7290GetKeyAndDisplay();
//            turn_gyro[0] = SM_temp;
//            AT24C_SendLenByte(0x0600, turn_gyro[0]);
//            OLED_Clear();
//        }

//        if (choice_1 == 2) {
//            OLED_ShowStr(8, 0, "decelerate_turn_g");
//            OLED_RAM_Show(8, 2, turn_gyro[1]);
//            OLED_RAM_Refresh_add();
//            SM_temp = ZLG7290GetKeyAndDisplay();
//            turn_gyro[1] = SM_temp;
//            AT24C_SendLenByte(0x0602, turn_gyro[1]);
//            OLED_Clear();
//        }

//        if (choice_1 == 3) {
//            OLED_ShowStr(8, 0, "ring_turn_g");
//            OLED_RAM_Show(8, 2, turn_gyro[2]);
//            OLED_RAM_Refresh_add();
//            SM_temp = ZLG7290GetKeyAndDisplay();
//            turn_gyro[2]  = SM_temp;
//            AT24C_SendLenByte(0x0604, turn_gyro[2]);
//            OLED_Clear();
//        }

//        if (choice_1 == 4) {
//            OLED_ShowStr(8, 0, "detour_turn_g");
//            OLED_RAM_Show(8, 2, turn_gyro[3]);
//            OLED_RAM_Refresh_add();
//            SM_temp = ZLG7290GetKeyAndDisplay();
//            turn_gyro[3]  = SM_temp;
//            AT24C_SendLenByte(0x0606, turn_gyro[3]);
//            OLED_Clear();
//        }

//        if (choice_1 == 5) {
//            OLED_ShowStr(8, 0, "brige_turn_g");
//            OLED_RAM_Show(8, 2, turn_gyro[4]);
//            OLED_RAM_Refresh_add();
//            SM_temp = ZLG7290GetKeyAndDisplay();
//            turn_gyro[4]  = SM_temp;
//            AT24C_SendLenByte(0x0608, turn_gyro[4]);
//            OLED_Clear();
//        }


//        if (choice_1 == 0) {
//            OLED_Clear();
//            break;
//        }

//    }

//    OLED_ShowStr(2, 6, "Finish");
//    OLED_RAM_Refresh_add();
//    delay_ms(500);
//    OLED_Clear();
//}



//void Scr_Set(void)
//{
//    int16 SM_temp = 0;
//    OLED_ShowStr(8, 0, "IPS144_see");
//    OLED_RAM_Refresh_add();

//    SM_temp = ZLG7290GetKeyAndDisplay();
//    see_value = SM_temp;
//    AT24C_SendLenByte(0x0308, see_value);
//    OLED_Clear();

//}


//void Memory_Set(void)
//{
//    int xdata a = 0;
//    int xdata sw = 6;
//    int xdata sw_1 = 6;
//    int xdata sw_2 = 6;
//	int xdata tmp = 0;
//    uint16 SM_temp = 0;
//    OLED_ShowStr(8, 0, "Memory_Set");
//    OLED_ShowStr(8, 2, "1:Array 2:Order");
//    OLED_ShowStr(8, 4, "3:Check");
//    OLED_RAM_Refresh_add();
//    SM_temp = ZLG7290GetKeyAndDisplay();
//    sw  = SM_temp;
//    OLED_Clear();

//    switch (sw) {
//        case 1:
//            OLED_Clear();
//            OLED_ShowStr(8, 0, "Ele Num:");
//            OLED_RAM_Show(8, 2, element_num);
//            OLED_RAM_Refresh_add();
//            SM_temp = ZLG7290GetKeyAndDisplay();
//            element_num = SM_temp;
//            AT24C_SendLenByte(0x0070, element_num);

//            for (a = 0; a < element_num ; a++) {
//                OLED_Clear();
//                OLED_ShowStr(8, 0, "Now Num:");
//                OLED_ShowStr(8, 2, "Value:");
//                OLED_RAM_Show(64, 0, a+1);
//                OLED_RAM_Show(64, 2, elements[a].type);
//                SM_temp = ZLG7290GetKeyAndDisplay();
//                elements[a].type = SM_temp;
//                AT24C_SendLenByte((0x0010+a*2), elements[a].type);

//                if (elements[a].type > 10) {
//                    OLED_Clear();
//                    OLED_ShowStr(8, 0, "OnDis:");
//                    OLED_ShowStr(8, 2, "EndDis:");
//                    OLED_RAM_Show(72, 0, elements[a].start_dis);
//                    OLED_RAM_Show(72, 2, elements[a].end_dis);
//                    SM_temp = ZLG7290GetKeyAndDisplay();
//                    elements[a].start_dis = SM_temp;
//                    AT24C_SendLenByte((0x0030+a*2), elements[a].start_dis);

//                    SM_temp = ZLG7290GetKeyAndDisplay();
//                    elements[a].end_dis = SM_temp;
//                    AT24C_SendLenByte((0x0050+a*2), elements[a].end_dis);

//                }
//            }

//            OLED_Clear();

//            break;

//        case 2:

//            OLED_ShowStr(8, 0, "Reverse");
//            OLED_ShowStr(8, 2, "0:no 1:yes");
//            OLED_RAM_Show(8, 4, reverse_element);
//            OLED_RAM_Refresh_add();

//            SM_temp = ZLG7290GetKeyAndDisplay();
//            reverse_element = SM_temp;

//            AT24C_SendLenByte(0x000c, reverse_element);
//            OLED_Clear();
//            OLED_ShowStr(8, 4, "OK");
//            OLED_RAM_Refresh_add();
//            delay_ms(500);
//            OLED_Clear();
//            break;

//        case 3:
//            		while(1)
//		{
//			OLED_RAM_Show(0,  0, elements[0].type);
//			OLED_RAM_Show(40, 0, elements[1].type);
//			OLED_RAM_Show(80, 0, elements[2].type);
//			
//			OLED_RAM_Show(0,  2, elements[3].type);		
//			OLED_RAM_Show(40, 2, elements[4].type);
//			OLED_RAM_Show(80, 2, elements[5].type);
//			
//			OLED_RAM_Show(0,  4, elements[6].type);
//			OLED_RAM_Show(40, 4, elements[7].type);		
//			OLED_RAM_Show(80, 4, elements[8].type);
//			
//			OLED_RAM_Show(0,  6, elements[9].type);
//			OLED_ShowStr (64, 6, "Check");
//			OLED_RAM_Refresh_add();
//		
//			tmp = CH450_Read();
//			
//			if (tmp == 0x0a)
//		{
//			OLED_Clear();
//			break;
//		}
//		}
//		break;


//    }

//    OLED_Clear();
//}


//void AD_Set(void)
//{
//    int16 SM_temp = 0;
//    int xdata choice_1 = 6;
//    int xdata choice_2 = 6;

//    for (;;) {
//        OLED_ShowStr(8, 0, "AD_SET");
//        OLED_ShowStr(8, 2, "1:Flag 2:AD_Max");
//        OLED_ShowStr(8, 4, "3:AD_Min4:AD");
//        OLED_RAM_Refresh_add();

//        SM_temp = ZLG7290GetKeyAndDisplay();
//        choice_1 = SM_temp;
//        OLED_Clear();

//        if (choice_1 == 1) {
//            OLED_ShowStr(8, 0, "SET_flag");
//            OLED_RAM_Show(8, 2, normalization_flag);
//            OLED_RAM_Refresh_add();
//            SM_temp = ZLG7290GetKeyAndDisplay();
//            normalization_flag = SM_temp;
//            AT24C_SendLenByte(0x0800, normalization_flag);
//            OLED_ShowStr(8, 4, "OK");
//            OLED_RAM_Refresh_add();
//            delay_ms(500);
//            OLED_Clear();
//        }

//        if (choice_1 == 2) {

//            for (;;) {
//                OLED_Clear();
//                OLED_ShowStr(8, 0, "AD_max");
//                OLED_ShowStr(8, 2, "1:L 2:R");
//                OLED_RAM_Refresh_add();
//                SM_temp = ZLG7290GetKeyAndDisplay();
//                choice_2 = SM_temp;

//                if (choice_2 == 1) {
//                    OLED_Clear();
//                    OLED_ShowStr(8, 0, "AD_L");
//                    OLED_RAM_Show(8, 2, AD_L_max);
//                    OLED_RAM_Refresh_add();

//                    SM_temp = ZLG7290GetKeyAndDisplay();
//                    AD_L_max = SM_temp;

//                    AT24C_SendLenByte(0x0802, AD_L_max);
//                    OLED_ShowStr(8, 4, "OK");
//                    OLED_RAM_Refresh_add();
//                    delay_ms(500);
//                }


//                if (choice_2 == 2) {
//                    OLED_Clear();
//                    OLED_ShowStr(8, 0, "AD_R");
//                    OLED_RAM_Show(8, 2, AD_R_max);
//                    OLED_RAM_Refresh_add();

//                    SM_temp = ZLG7290GetKeyAndDisplay();
//                    AD_R_max = SM_temp;

//                    AT24C_SendLenByte(0x0808, AD_R_max);
//                    OLED_ShowStr(8, 4, "OK");
//                    OLED_RAM_Refresh_add();
//                    delay_ms(500);
//                }


//                if (choice_2 == 0) {
//                    OLED_Clear();
//                    OLED_ShowStr(8, 0, "BREAK");
//                    OLED_RAM_Refresh_add();

//                    break;
//                }


//            }

//        }

//        if (choice_1 == 3) {


//            for (;;) {
//                OLED_Clear();
//                OLED_ShowStr(8, 0, "AD_Min");
//                OLED_ShowStr(8, 2, "1:L 2:R");
//                OLED_RAM_Refresh_add();
//                SM_temp = ZLG7290GetKeyAndDisplay();
//                choice_2 = SM_temp;

//                if (choice_2 == 1) {
//                    OLED_Clear();
//                    OLED_ShowStr(8, 0, "AD_L_min");
//                    OLED_RAM_Show(8, 2, AD_L_min);
//                    OLED_RAM_Refresh_add();

//                    SM_temp = ZLG7290GetKeyAndDisplay();
//                    AD_L_min = SM_temp;

//                    AT24C_SendLenByte(0x080c, AD_L_min);
//                    OLED_ShowStr(8, 4, "OK");
//                    OLED_RAM_Refresh_add();
//                    delay_ms(500);
//                }

//               

//                if (choice_2 == 4) {
//                    OLED_Clear();
//                    OLED_ShowStr(8, 0, "AD_R_min");
//                    OLED_RAM_Show(8, 2, AD_R_min);
//                    OLED_RAM_Refresh_add();

//                    SM_temp = ZLG7290GetKeyAndDisplay();
//                    AD_R_min = SM_temp;

//                    AT24C_SendLenByte(0x0904, AD_R_min);
//                    OLED_ShowStr(8, 4, "OK");
//                    OLED_RAM_Refresh_add();
//                    delay_ms(500);
//                }

//              

//                if (choice_2 == 0) {
//                    OLED_Clear();
//                    OLED_ShowStr(8, 0, "BREAK");
//                    OLED_RAM_Refresh_add();

//                    break;
//                }

//            }
//        }

//        if (choice_1 == 0) {
//            OLED_Clear();
//            OLED_ShowStr(8, 0, "BREAK");
//            OLED_RAM_Refresh_add();

//            break;
//        }

//        //        if (choice_1 == 4) {
//        //            for (;;) {
//        //                OLED_Clear();
//        //                OLED_ShowStr(8, 0, "ADmax&ADmin");
//        //                OLED_ShowStr(8, 2, "1:ADmax");
//        //                OLED_ShowStr(8, 4, "2:ADmin");
//        //                OLED_RAM_Refresh_add();
//        //                SM_temp = ZLG7290GetKeyAndDisplay();
//        //                choice_2 = SM_temp;

//        //                if (choice_2 == 1) {
//        //                    OLED_Clear();
//        //                    OLED_ShowStr(8, 0, "ADmax");
//        //                    OLED_RAM_Show(8, 2, AD_max);
//        //                    OLED_RAM_Refresh_add();

//        //                    SM_temp = ZLG7290GetKeyAndDisplay();
//        //                    AD_max = SM_temp;

//        //                    AT24C_SendLenByte(0x0710, AD_max);
//        //                    OLED_ShowStr(8, 4, "OK");
//        //                    OLED_RAM_Refresh_add();
//        //                    delay_ms(500);
//        //                }

//        //                if (choice_2 == 2) {
//        //                    OLED_Clear();
//        //                    OLED_ShowStr(8, 0, "ADmin");
//        //                    OLED_RAM_Show(8, 2, AD_min);
//        //                    OLED_RAM_Refresh_add();

//        //                    SM_temp = ZLG7290GetKeyAndDisplay();
//        //                    AD_min = SM_temp;

//        //                    AT24C_SendLenByte(0x0712, AD_min);
//        //                    OLED_ShowStr(8, 4, "OK");
//        //                    OLED_RAM_Refresh_add();
//        //                    delay_ms(500);
//        //                }




//        //                if (choice_2 == 0) {
//        //                    OLED_Clear();
//        //                    OLED_ShowStr(8, 0, "BREAK");
//        //                    OLED_RAM_Refresh_add();

//        //                    break;
//        //                }

//        //            }
//        //        }

//    }

//    OLED_ShowStr(2, 6, "Finish");
//    OLED_RAM_Refresh_add();
//    delay_ms(250);
//    OLED_Clear();
//}

//void AT24C_data_read(void)
//{
//	
//	sPID_SpeedL.Kp = AT24C_RcvLenByte(0x0412);
//    sPID_SpeedL.Ki = AT24C_RcvLenByte(0x0414);
//    sPID_SpeedR.Kp = AT24C_RcvLenByte(0x0416);
//    sPID_SpeedR.Ki = AT24C_RcvLenByte(0x0418);
////		AT24C_SendLenByte(0x0412, sPID_SpeedL.Kp);
////		AT24C_SendLenByte(0x0414, sPID_SpeedL.Ki);
////		AT24C_SendLenByte(0x0416, sPID_SpeedR.Kp);
////		AT24C_SendLenByte(0x0418, sPID_SpeedR.Ki);
//	
//    //First
//    element_num = AT24C_RcvLenByte(0x0070);
//    elements[0].type = AT24C_RcvLenByte(0x0010);
//    elements[1].type = AT24C_RcvLenByte(0x0012);
//    elements[2].type = AT24C_RcvLenByte(0x0014);
//    elements[3].type = AT24C_RcvLenByte(0x0016);
//    elements[4].type = AT24C_RcvLenByte(0x0018);
//    elements[5].type = AT24C_RcvLenByte(0x0020);
//    elements[6].type = AT24C_RcvLenByte(0x0022);
//    elements[7].type = AT24C_RcvLenByte(0x0024);
//    elements[8].type = AT24C_RcvLenByte(0x0026);
//    elements[9].type = AT24C_RcvLenByte(0x0028);

//    elements[0].start_dis = AT24C_RcvLenByte(0x0030);
//    elements[1].start_dis = AT24C_RcvLenByte(0x0032);
//    elements[2].start_dis = AT24C_RcvLenByte(0x0034);
//    elements[3].start_dis = AT24C_RcvLenByte(0x0036);
//    elements[4].start_dis = AT24C_RcvLenByte(0x0038);
//    elements[5].start_dis = AT24C_RcvLenByte(0x0040);
//    elements[6].start_dis = AT24C_RcvLenByte(0x0042);
//    elements[7].start_dis = AT24C_RcvLenByte(0x0044);
//    elements[8].start_dis = AT24C_RcvLenByte(0x0046);
//    elements[9].start_dis = AT24C_RcvLenByte(0x0048);

//    elements[0].end_dis = AT24C_RcvLenByte(0x0050);
//    elements[1].end_dis = AT24C_RcvLenByte(0x0052);
//    elements[2].end_dis = AT24C_RcvLenByte(0x0054);
//    elements[3].end_dis = AT24C_RcvLenByte(0x0056);
//    elements[4].end_dis = AT24C_RcvLenByte(0x0058);
//    elements[5].end_dis = AT24C_RcvLenByte(0x0060);
//    elements[6].end_dis = AT24C_RcvLenByte(0x0062);
//    elements[7].end_dis = AT24C_RcvLenByte(0x0064);
//    elements[8].end_dis = AT24C_RcvLenByte(0x0066);
//    elements[9].end_dis = AT24C_RcvLenByte(0x0068);


//    Memory_enable  = AT24C_RcvLenByte(0x0006);
//    reverse_element= AT24C_RcvLenByte(0x000c);
//    //Second
//    test_mode      = AT24C_RcvLenByte(0x0100);
//    start_time     = AT24C_RcvLenByte(0x0102);
//    test_time      = AT24C_RcvLenByte(0x0104);
//    run_time       = AT24C_RcvLenByte(0x0106);
//    //Third
//    element_Array  = AT24C_RcvLenByte(0x0200);
//    PID_Mode       = AT24C_RcvLenByte(0x0204);

//    see_value      = AT24C_RcvLenByte(0x0308);
//    //Fifth
//    turn_p_base[0]  = AT24C_RcvLenByte(0x0400);
//    turn_p_base[1]  = AT24C_RcvLenByte(0x0402);
//    turn_p_base[2]  = AT24C_RcvLenByte(0x0404);
//    turn_p_base[3]  = AT24C_RcvLenByte(0x0406);
//    turn_p_base[4]  = AT24C_RcvLenByte(0x0408);

//    //Sixth
//    turn_d[0]  = AT24C_RcvLenByte(0x0500);
//    turn_d[1]  = AT24C_RcvLenByte(0x0502);
//    turn_d[2]  = AT24C_RcvLenByte(0x0504);
//    turn_d[3]  = AT24C_RcvLenByte(0x0506);
//    turn_d[4]  = AT24C_RcvLenByte(0x0508);

//    //Seventh
//    turn_gyro[0]  = AT24C_RcvLenByte(0x0600);
//    turn_gyro[1]  = AT24C_RcvLenByte(0x0602);
//    turn_gyro[2]  = AT24C_RcvLenByte(0x0604);
//    turn_gyro[3]  = AT24C_RcvLenByte(0x0606);
//    turn_gyro[4]  = AT24C_RcvLenByte(0x0608);

//    //Eighth
//    Speed_Ref[0]  = AT24C_RcvLenByte(0x0700);
//    Speed_Ref[1]  = AT24C_RcvLenByte(0x0702);
//    Speed_Ref[2]  = AT24C_RcvLenByte(0x0704);
//    Speed_Ref[3]  = AT24C_RcvLenByte(0x0706);
//    Speed_Ref[4]  = AT24C_RcvLenByte(0x0708);


//    Speed_Low  = AT24C_RcvLenByte(0x0810);

//    //Ninth
//    normalization_flag = AT24C_RcvLenByte(0x0800);
////    AD_L1_max = AT24C_RcvLenByte(0x0802);
////    AD_L2_max = AT24C_RcvLenByte(0x0804);
////    AD_M_max = AT24C_RcvLenByte(0x0806);
////    AD_R1_max = AT24C_RcvLenByte(0x0808);
////    AD_R2_max = AT24C_RcvLenByte(0x080a);

////    AD_L1_min = AT24C_RcvLenByte(0x080c);
////    AD_L2_min = AT24C_RcvLenByte(0x080e);
////    AD_M_min = AT24C_RcvLenByte(0x0902);
////    AD_R1_min = AT24C_RcvLenByte(0x0904);
////    AD_R2_min = AT24C_RcvLenByte(0x0906);

//    //Tenth

//    //eleventh
//    turn_p_cub[0]  = AT24C_RcvLenByte(0x0b00);
//    turn_p_cub[1]  = AT24C_RcvLenByte(0x0b02);
//    turn_p_cub[2]  = AT24C_RcvLenByte(0x0b04);
//    turn_p_cub[3]  = AT24C_RcvLenByte(0x0b06);
//    turn_p_cub[4]  = AT24C_RcvLenByte(0x0b08);
//    turn_p_cub[5]  = AT24C_RcvLenByte(0x0b0a);




//    Default.Ver_weight  = AT24C_RcvLenByte(0x0718);
//    Default.Pal_weight  = AT24C_RcvLenByte(0x071a);

//}



///************************************************�ײ�***********************************************/
///**
// * @brief  ����I2C��ʼ��
// * @param  ��
// * @return ��
// */
//void KEY_DELAY(int m)/////��ʱ�ź�
//{
//    int k = 0;

//    while (m-1) {
//        m = -1+m;
//        k = 600;

//        while (k) k = -1+k;
//    }
//}

//void Keyboard_I2C_Init(void)
//{
//    IIC_SDA_H;
//    KEY_DELAY(1);
//    IIC_SCL_H;
//    KEY_DELAY(1);
//}

///**
// * @brief  ����I2C��ʼ�ź�
// * @param  ��
// * @return ��
// */
//void Keyboard_I2C_Start(void)
//{
//    IIC_SDA_OUT();
//    //IIC_DELAY(1);
//    IIC_SDA_H;
//    KEY_DELAY(1);
//    IIC_SCL_H;
//    KEY_DELAY(1);
//    IIC_SDA_L;
//    KEY_DELAY(1);
//    IIC_SCL_L;
//    KEY_DELAY(1);
//}

///**
// * @brief  ����I2C�����ź�
// * @param  ��
// * @return ��
// */
//void Keyboard_I2C_Stop(void)
//{
//    IIC_SDA_L;
//    IIC_SCL_L;
//    KEY_DELAY(1);
//    IIC_SCL_H;
//    KEY_DELAY(1);
//    IIC_SDA_L;
//    KEY_DELAY(1);
//    IIC_SDA_H;
//    KEY_DELAY(1);
//    IIC_SCL_H;
//}

///**
// * @brief  ����I2CӦ���ź�
// * @param  ��
// * @return ��
// */
//void Keyboard_I2C_Ack(void)
//{
//    IIC_SCL_L;
//    KEY_DELAY(1);
//    IIC_SDA_L;
//    KEY_DELAY(1);
//    IIC_SCL_H;
//    KEY_DELAY(1);
//    IIC_SCL_L;
//    KEY_DELAY(1);
//}

///**
// * @brief  ����I2CӦ���ź�
// * @param  ��
// * @return ��
// */
//void Keyboard_I2C_nAck(void)
//{
//    IIC_SCL_L;
//    KEY_DELAY(1);
//    IIC_SDA_H;
//    KEY_DELAY(1);
//    IIC_SCL_H;
//    KEY_DELAY(1);
//    IIC_SCL_L;
//    KEY_DELAY(1);
//}



///**
// * @brief  ����I2Cдһ���ֽ�
// * @param  data Ҫд������
// * @return ��
// */
//void Keyboard_I2C_WriteByte(uint8 x)
//{
//    uint8 i = 8;

//    while (i) {
//        i = -1+i;
//        IIC_SCL_L;

//        if (x & 0x80)
//            IIC_SDA_H;
//        else
//            IIC_SDA_L;

//        x <<= 1;
//        KEY_DELAY(1);
//        IIC_SCL_H;
//        KEY_DELAY(1);
//    }
//}

///**
// * @brief  ����I2C��һ���ֽ�
// * @param  ackMode �Ƿ���Ӧ���ź�
// *-        0 ����һ���ֽ�ʲôҲ����(CH455��ͨѶʱ��)
// *-        1 ����Ӧ��nAck(���һ���ֽ�)
// *-        2 ����Ӧ��Ack(����δ�������)
// * @return ���յ�������
// */
//uint8 Keyboard_I2C_ReadByte(void)
//{
//    uint8 i;
//    uint8 x = 0; /* ������յ������� */

//    /* ����SDA����Ϊ���� */
//    IIC_SDA_H;
//    IIC_SDA_IN();   //����

//    for (i = 0; i < 8; i++) {
//        i=-1+i;
//        x <<= 1;
//        IIC_SCL_L;
//        KEY_DELAY(1);
//        IIC_SCL_H;
//        KEY_DELAY(1);

//        if (IIC_DATA) {
//            x |= 0x01;
//        }
//    }

//    IIC_SDA_H;
//    KEY_DELAY(1);
//    IIC_SCL_H;  // ������ЧӦ��
//    KEY_DELAY(1);
//    IIC_SCL_L;
//    return x;
//}

///**
// * @brief  �ȴ�Ӧ���ź�
// * @param  ��
// * @return ����״̬��
// * @retval false û�н��յ�Ӧ���ź�
// * @retval true ���յ�Ӧ���ź�
// */
//uint8 Keyboard_I2C_Wait_Ack(void)
//{
//    uint8 ErrTime=0;
//    IIC_SCL_L;
//    KEY_DELAY(1);
//    IIC_SDA_H;
//    KEY_DELAY(1);
//    IIC_SDA_IN();      //SDA����Ϊ����
//    KEY_DELAY(1);
//    IIC_SCL_H;
//    KEY_DELAY(1);

//    while (IIC_DATA) {
//        ErrTime++;

//        if (ErrTime > 250) {
//            Keyboard_I2C_Stop();
//            return 0;
//        }
//    }

//    IIC_SCL_L;//ʱ�����0
//    IIC_SDA_OUT();    //SDA����Ϊ���
//    KEY_DELAY(1);
//    return 1;
//}

///**
// * @brief  ����I2C��ӻ�д��һ���ֽڵ�����
// * @param  slaveAddr �ӻ���ַ(8λд��ַ)
// * @param  regAddr �ӻ�����Ĵ�����ַ
// * @param  regAddrType �ӻ�����Ĵ�����ַ���� @ref keyboard_i2c_reg_addr_t
// * @param  data Ҫд������
// * @return д��״̬
// * @retval false д��ʧ��
// * @retval true д��ɹ�
// */
//uint8 Keyboard_I2C_Write(uint8 slaveAddr, uint16 regAddr, keyboard_i2c_reg_addr_t regAddrType, uint8 x)
//{

//    /*
//    ���ݸ�ʽ����б�߱�ʾ��������, ��б�߱�ʾ�ɴӻ�����
//    ---------------------------------------------------------------------
//    |\\\\\|\\\\\\\\\\\\\|\\\\|   |\\\\\\\\\\\\\\\\\\\\|   |\\\\|   |\\\\|
//    |Start|Slave Address|W(0)|Ack|Data(Slave Register)|Ack|Data|Ack|Stop|
//    |\\\\\|\\\\\\\\\\\\\|\\\\|   |\\\\\\\\\\\\\\\\\\\\|   |\\\\|   |\\\\|
//    ---------------------------------------------------------------------
//    */

//    Keyboard_I2C_Start();
//    Keyboard_I2C_WriteByte(slaveAddr); /* ����Ҫд�Ĵӻ���ַ */

//    if (!Keyboard_I2C_Wait_Ack()) {    /* ����Ƿ��ͳɹ� */
//        Keyboard_I2C_Stop();
//        return 0; /* ����ʧ�� */
//    }

//    if (Keyboard_I2C_RegAddr16Bit == regAddrType) {
//        uint8 regAddrh = regAddr >> 8;
//        Keyboard_I2C_WriteByte(regAddrh); /* ���ͼĴ�����8λ��ַ */

//        if (!Keyboard_I2C_Wait_Ack()) {
//            Keyboard_I2C_Stop();
//            return 0;
//        }
//    }

//    /* �ж��Ƿ����ӵ�ַ */
//    if (Keyboard_I2C_NoSubaddress != regAddrType) {
//        Keyboard_I2C_WriteByte((uint8)regAddr); /* ����Ҫд�ӻ��ľ���Ĵ�����ַ(�ӵ�ַ) */

//        if (!Keyboard_I2C_Wait_Ack()) {
//            Keyboard_I2C_Stop();
//            return 0;
//        }
//    }

//    Keyboard_I2C_WriteByte(x); /* ����Ҫд������ */

//    if (!Keyboard_I2C_Wait_Ack()) {
//        Keyboard_I2C_Stop();
//        return 0;
//    }

//    Keyboard_I2C_Stop();
//    return 1; /* ���ͳɹ� */
//}

///**
// * @brief  ����I2C��ӻ���ȡһ���ֽڵ�����
// * @param  slaveAddr �ӻ���ַ(8λ����ַ)
// * @param  regAddr �ӻ�����Ĵ�����ַ
// * @param  regAddrType �ӻ�����Ĵ�����ַ���� @ref keyboard_i2c_reg_addr_t
// * @param  data �洢��ȡ�������ݵ�ָ��
// * @return ��ȡ״̬
// * @retval false ��ȡʧ��
// * @retval true ��ȡ�ɹ�
// */
//uint8 Keyboard_I2C_Read(uint8 slaveAddr,
//                        uint16 regAddr,
//                        keyboard_i2c_reg_addr_t regAddrType,
//                        uint8 *x)
//{
//    /*
//    ���ݸ�ʽ����б�߱�ʾ��������, ��б�߱�ʾ�ɴӻ�����
//    ---------------------------------------------------------------------------------------------------
//    |\\\\\|\\\\\\\\\\\\\|\\\\|   |\\\\\\\\\\\\\\\\\\\\|   |\\\\\|\\\\\\\\\\\\\|\\\\|   |    |\\\\|\\\\|
//    |Start|Slave Address|W(0)|Ack|Data(Slave Register)|Ack|Start|Slave Address|R(1)|Ack|Data|nAck|Stop|
//    |\\\\\|\\\\\\\\\\\\\|\\\\|   |\\\\\\\\\\\\\\\\\\\\|   |\\\\\|\\\\\\\\\\\\\|\\\\|   |    |\\\\|\\\\|
//    ---------------------------------------------------------------------------------------------------
//    */
//    uint8 slaveAddr1 = slaveAddr + 1;
//    Keyboard_I2C_Start();
//    Keyboard_I2C_WriteByte(slaveAddr); /* ����Ҫ���Ĵӻ���ַ */

//    if (!Keyboard_I2C_Wait_Ack()) {    /* ����Ƿ��ͳɹ� */
//        Keyboard_I2C_Stop();
//        return 0; /* ����ʧ�� */
//    }

//    if (Keyboard_I2C_RegAddr16Bit == regAddrType) {
//        uint8 regAddrh = regAddr >> 8;
//        Keyboard_I2C_WriteByte(regAddrh); /* ����Ҫ���ӻ��ľ���Ĵ����ĸ�8λ��ַ */

//        if (!Keyboard_I2C_Wait_Ack()) {
//            Keyboard_I2C_Stop();
//            return 0;
//        }
//    }

//    /* �ж��Ƿ����ӵ�ַ */
//    if (Keyboard_I2C_NoSubaddress != regAddrType) {
//        Keyboard_I2C_WriteByte((uint8)regAddr); /* ����Ҫ���ӻ��ľ���Ĵ�����ַ */

//        if (!Keyboard_I2C_Wait_Ack()) {
//            Keyboard_I2C_Stop();
//            return 0;
//        }

//        Keyboard_I2C_Start();                  /* ���·��Ϳ�ʼ�ź�, ��Ҫ */
//        Keyboard_I2C_WriteByte(slaveAddr1); /* �������ģʽ[7λ��ַ+1λ��д(1-д, 0-��)]*/

//        if (!Keyboard_I2C_Wait_Ack()) {
//            Keyboard_I2C_Stop();
//            return 0;
//        }

//        *x = Keyboard_I2C_ReadByte(); /* ��ȡ����, ֻ��һ������, ��Ҫ����nAck */
//    }
//    else {
//        *x = Keyboard_I2C_ReadByte(); /* ���ӵ�ַ */
//    }

//    Keyboard_I2C_Stop();
//    return 1; /* ���ͳɹ� */
//}