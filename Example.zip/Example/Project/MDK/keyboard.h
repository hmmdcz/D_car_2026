#ifndef __KEYBOARD_H__
#define __KEYBOARD_H__


#include "headfile.h"


sbit K_SCL = P7^7;
sbit K_SDA = P7^6;

#define IIC_SDA_OUT()  {P3M0 &= 0xFB;P3M1 &= 0xFB;}
#define IIC_SDA_IN()   {P4M0 &= 0xFB;P4M1 |= 0x04;}
#define IIC_DATA         K_SDA
#define IIC_SDA_H      K_SDA = 1
#define IIC_SCL_H      K_SCL = 1
#define IIC_SDA_L      K_SDA = 0
#define IIC_SCL_L      K_SCL = 0

#define WID 8

typedef enum _keyboard_i2c_reg_addr {
    Keyboard_I2C_RegAddr8Bit,  /*!< 8λ */
    Keyboard_I2C_RegAddr16Bit, /*!< 16λ */
    Keyboard_I2C_NoSubaddress  /*!< ���ӵ�ַ: CH455 */
} keyboard_i2c_reg_addr_t;

uint16 ZLG7290GetKeyAndDisplay(void);
void Choise(void);
void Keyboard_I2C_Init(void);
void KEY_DELAY(int m);
void Keyboard_I2C_Init(void);
void Keyboard_I2C_Start(void);
void Keyboard_I2C_Stop(void);
void Keyboard_I2C_Ack(void);
void Keyboard_I2C_nAck(void);
void Keyboard_I2C_WriteByte(uint8 x);
uint8 Keyboard_I2C_ReadByte(void);
uint8 Keyboard_I2C_Wait_Ack(void);
uint8 Keyboard_I2C_Write(uint8 slaveAddr, uint16 regAddr, keyboard_i2c_reg_addr_t regAddrType, uint8 x);
uint8 Keyboard_I2C_Read(uint8 slaveAddr, uint16 regAddr, keyboard_i2c_reg_addr_t regAddrType, uint8 *x);

void Mode_Test(void);
void Speed_Mode_set(void);
void Speed_Low_set(void);
void Turn_DDD(void);
void Turn_PPP(void);
void Turn_P_cub(void);
void AD_Set(void);
void Turn_Gyr(void);
void Scr_Set(void);
void Memory_Set(void);
void Element_Set(void);
void AT24C_data_read(void);
void K_N_Set(void);
#endif