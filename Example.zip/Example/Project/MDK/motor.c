#include "motor.h"


void Mot_L_Init(void)
{
    //    uint16 pwmDuty = 0;
    //    gpio_init(MOT_L_DIR_PIN, GPO, MOT_L_FOREWARD_LEVEL, GPO_PUSH_PULL);
    gpio_mode(MOT_L_DIR_PIN, GPO_PP);
    //    pwmDuty = duty;

    //    pwm_init(MOT_L_PWM_PIN, MOT_PWM_FREQ, pwmDuty);
    pwm_init(MOT_L_PWM_PIN, 15000, 5000);
}


void Mot_R_Init(void)
{
    //    unsigned long pwmDuty = 0;
    //    gpio_init(MOT_R_DIR_PIN, GPO, MOT_R_FOREWARD_LEVEL, GPO_PUSH_PULL);
    //    pwmDuty = duty;

    //    pwm_init (MOT_R_PWM_PIN,MOT_PWM_FREQ, pwmDuty);
    gpio_mode(MOT_R_DIR_PIN, GPO_PP);

    pwm_init(MOT_R_PWM_PIN, 15000, 0);

}


void Mot_SetPwmDuty_L(int32 duty)
{
    uint32 pwmDuty = 0;

    if (duty > 0) {

        MOT_L_DIR_PIN = 1;
        pwmDuty =  duty;
    }
    else {
        MOT_L_DIR_PIN = 0;
        pwmDuty = -duty;
    }

    //    pwm_set_duty(MOT_L_PWM_PIN, pwmDuty);
    pwm_duty(MOT_L_PWM_PIN, pwmDuty);

}


void Mot_SetPwmDuty_R(int32 duty)
{
    uint32 pwmDuty = 0;

    if (duty > 0) {
        //        gpio_pull_set(MOT_R_DIR_PIN, NOPULL);
        MOT_R_DIR_PIN = 1;
        pwmDuty = duty;
    }
    else {
        //        gpio_pull_set(MOT_R_DIR_PIN, PULLUP);
        MOT_R_DIR_PIN = 0;
        pwmDuty = -duty;
    }

    pwm_duty(MOT_R_PWM_PIN, pwmDuty);
}


void speed_PIDInit(void)
{

    sPID_SpeedL.Ref = 0;           //�ٶ��趨ֵ
    sPID_SpeedL.FeedBack = 0;       //���ַ���ֵ
    sPID_SpeedL.PreError = 0;       //��һ��ƫ��
    sPID_SpeedL.PreDerror = 0;      //��һ��΢��
    sPID_SpeedL.Output = 0;          //���

    sPID_SpeedL.Kp = 120;
    sPID_SpeedL.Ki = 25;          //25;
    sPID_SpeedL.Kd = 0;          //10;
    sPID_SpeedL.i_error = 0;
    sPID_SpeedL.max_Error = 100;
    sPID_SpeedL.output_1 = 0;


    sPID_SpeedL.ffc.conf_1 = 300;
    sPID_SpeedL.ffc.conf_2 = 90;
    sPID_SpeedL.ffc.conf_3 = 0;
    sPID_SpeedL.ffc.input = 0;
    sPID_SpeedL.ffc.last_input = 0;
    sPID_SpeedL.ffc.pre_input = 0;
    sPID_SpeedL.ffc.output = 0;



    sPID_SpeedR.Ref = 0;
    sPID_SpeedR.FeedBack = 0;
    sPID_SpeedR.PreError = 0;
    sPID_SpeedR.PreDerror = 0;
    sPID_SpeedR.Output = 0;

    sPID_SpeedR.Kp = 120;
    sPID_SpeedR.Ki = 25;          //25;
    sPID_SpeedR.Kd = 0;          //10;
    sPID_SpeedR.i_error = 0;
    sPID_SpeedR.max_Error = 100;
    sPID_SpeedR.output_1 = 0;

    sPID_SpeedR.ffc.conf_1 = 300;
    sPID_SpeedR.ffc.conf_2 = 90;
    sPID_SpeedR.ffc.conf_3 = 0;
    sPID_SpeedR.ffc.input = 0;
    sPID_SpeedR.ffc.last_input = 0;
    sPID_SpeedR.ffc.pre_input = 0;
    sPID_SpeedR.ffc.output = 0;
}

int speed_PIDCalc(struct PID_Speed *pp)  //����ʽPID
{
    int error = 0;
    int d_error = 0;
    int dd_error = 0;
    error = (int)(pp->Ref) - (int)(pp->FeedBack);   // �趨ֵ������ֵΪƫ��  ����
    d_error = error - (int)(pp->PreError);
    dd_error = d_error - (int)(pp->PreDerror);

    pp->PreError = error;        //������һ��ƫ��
    pp->PreDerror = d_error;




    pp->output_1 += (int)(pp->Kp/10 * d_error + pp->Ki/10 * error + pp->Kd/10 * dd_error);
    pp->output_1 = Range(-9999, pp->output_1, 9999);
    pp->Output = pp->output_1 ;


    if (ABS(error) > pp->max_Error) {

        pp->Output += FeedForwardCtrl(pp->Ref, &(pp->ffc));

    }

    pp->Output = Range(-9999, pp->Output, 9999);  //����޷�

    return (pp->Output);
}




/***********************************************
* @brief : ǰ������
* @param : target:ǰ����������
*          ffc:ǰ�����ƽṹ��
* @return: ffc->output:ǰ�����������
* @date  :
* @author: CFB
************************************************/

int FeedForwardCtrl(int target, struct FFC *ffc)
{
    ffc->input = target;

    ffc->output = (int)(ffc->conf_1*(ffc->input-ffc->last_input)/10+ffc->conf_2*(ffc->input-2*ffc->last_input+ffc->pre_input)/10)+ffc->conf_3;

    ffc->pre_input = ffc->last_input;
    ffc->last_input = ffc->input;

    ffc->output =  Range(-9999, ffc->output, 9999);

    return ffc->output;
}