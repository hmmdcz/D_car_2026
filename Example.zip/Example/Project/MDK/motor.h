

/* 防止重复定义 ------------------------------------------------------------- */
#ifndef __MOTOR_H
#define __MOTOR_H

/* 头文件------------------------------------------------------------------ */

#include "headfile.h"
//#include <stdbool.h>


#define MOT_PWM_FREQ 15000


#define MOT_L_PWM_PIN PWMA_CH4P_P66       //PWMA_CH3P_P64
#define MOT_L_DIR_PIN P67



#define MOT_R_PWM_PIN PWMA_CH3P_P64
#define MOT_R_DIR_PIN P65


extern struct FFC {
    float conf_1;
    float conf_2;
    float conf_3;
    int input;
    int last_input;
    int pre_input;
    int output;

} FFC;

extern struct PID_Speed { //PID参数结构体
    int Ref;
    int FeedBack;
    int PreError;
    int PreDerror;
    uint16 Kp;
    uint16 Ki;
    uint16 Kd;
    uint32 i_error;

    int static_Error;
    int max_Error;
    int mid_Error;

    int output_1;
    int output_2;

    int switch_step;
    int switch_duration;



    int Output;

    struct FFC ffc;

} PID_Speed;


/* 函数声明 ---------------------------------------------------------------- */

void Mot_L_Init(void);
void Mot_R_Init(void);
void Mot_SetPwmDuty_L(int32 duty);
void Mot_SetPwmDuty_R(int32 duty);
extern int speed_PIDCalc(struct PID_Speed *pp);
extern void speed_PIDInit(void);
int FeedForwardCtrl(int target, struct FFC *ffc);

#endif /* __MOTOR_H */
