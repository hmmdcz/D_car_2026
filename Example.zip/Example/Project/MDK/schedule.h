#ifndef __SCHEDULE_H__
#define __SCHEDULE_H__

#include "headfile.h"

//***************���ֱ�־***************//

extern uint32 g_time;  //ʱ�����



//*********���********************//

extern float AD_feedback;


//*********�ٿز���********************//

extern float speed_set;

//*********ת�����********************//

extern float bias;
extern float pre_bias;
extern float de_bias;

extern g_turn_control;

extern float turn_p;
extern float turn_d;



//****************PWM*****************//
extern int PwmL; //
extern int PwmR; //
extern struct PID_Speed sPID_SpeedL;
extern struct PID_Speed sPID_SpeedR;


/**********��������**********/
extern void Control_TimeOut_IRQHandler(void);  /* �ٿ��ж� */


void Sensor_get(void);
void LR_control(void);  //�������
void turn_control(void);
void Running_Init(void);
void Test_control(void);
void SpeedSet_Control(void);
void Error_get(void);






#endif