#ifndef __SYSTEM_INIT_H
#define __SYSTEM_INIT_H

/* ͷ�ļ� ------------------------------------------------------------------ */
#include "headfile.h"

/* �궨�� ------------------------------------------------------------------ */


/* �������� ---------------------------------------------------------------- */

extern void System_Init(void);
extern void HardWare_Init(void);
void Counter_Init(void);
void Uart_AllInit(void);
void Mot_Init(void);
void Counter_Init(void);
//void keyboard_Init(void);

#endif /* __SYSTEM_INIT_H */
